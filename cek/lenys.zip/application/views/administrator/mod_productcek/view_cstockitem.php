<?php 
    echo "<div class='card card-info'>
                <div class='card-header with-border'>
                  <h3 class='card-title'>Stock Item Update</h3>
                </div>
              <div class='card-body'>";
              $attributes = array('class'=>'form-horizontal','role'=>'form');
            
           
$tes = stripslashes($record[link]);
          echo "<div class='row'><div class='col-10 embed-responsive-21by9'>$tes</div></div>
           
            </div></div>";

                  

