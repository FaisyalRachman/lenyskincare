<?php
echo $error; 
?>