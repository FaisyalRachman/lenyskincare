<section id="services" class="services" style="margin-top:66px;">
  <div class="container">
<div class="contentbg">
    <div class="section-title">
      <h2>Profesional Team </h2>
    </div>
    <div class="row">
   
    <div class="col-lg-4">
   
   </div>
    <div class="col-lg-4">
     <div class="icon-box">
       <img src="<?php echo base_url(); ?>asset/images/profesional1.png" alt="" class="img-fluid" style="width:53%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
         <p><b>Eko Hartanto</b></p>Founder of Integra Mitra Solusi
     </div>
   </div>
    <div class="col-lg-4">
 
   </div>
 
</div><br>
    <div class="row">
   
   
    <div class="col-lg-3">
    <div class="icon-box">
       <img src="<?php echo base_url(); ?>asset/images/profesional0.png" alt="" class="img-fluid" style="width:53%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
       <p><b>Davis Hartanto</b></p>Manager division of commercial
     </div>
   </div>
    <div class="col-lg-3">
     <div class="icon-box">
       <img src="<?php echo base_url(); ?>asset/images/profesional2.png" alt="" class="img-fluid" style="width:53%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
               <p><b>Didin Alqurani</b></p>Manager People Development
     </div>
   </div>
   <div class="col-lg-3">
    <div class="icon-box">
       <img src="<?php echo base_url(); ?>asset/images/profesional4.png" alt="" class="img-fluid" style="width:53%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
         <p><b>Astria Septia Reski</b></p>Manager Finanace & TAX
     </div>
 </div>
 <div class="col-lg-3">
    <div class="icon-box">
       <img src="<?php echo base_url(); ?>asset/images/profesional3.png" alt="" class="img-fluid" style="width:53%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
         <p><b>Azima Sapta Putra</b></p>SPV Warehouse & Logistic
     </div>
 </div>
</div>
<br><br>
</div>
</div>
</section>