 <section id="galery" class="galery" style="margin-top:8px !important">
    <div class="row">
    <div class="col-lg-3 vh-100 d-flex justify-content-center align-items-center" style="background:#594A9D;">
 <ul style="list-style-type: none !important;">
 <li>
    <div class="box">
  <select class="common_selector brand">
    <option value="" disabled>pilih galeri</option>
    <option value="3">HOLLYLAND TOUR</option>
    <option value="65">AMERICA</option>
    <option value="66">AUSTRALIA</option>
    <option value="67">ASIA</option>
    <option value="69">EUROPE</option>
    </select>
</div>

</li>
</ul>
</div>

        <div class="col-lg-9 d-flex align-items-stretch" style="margin-top:34px;">
   
        <div class="row filter_data">

</div>
        </div>

     
<div class="section-title">
      <div class="pagination">
        <?php echo $this->pagination->create_links(); ?>
      </div>
  </div>
    </div>
 
</section>

