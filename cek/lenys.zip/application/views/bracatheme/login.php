<section id="about" class="about">
 	<div class="container" style="margin-top: 120px;">

 		<div class="row">
 			<div class="col-xl-12 justify-content-center align-items-stretch">
                 <div class="from-group">
 			<div class="btn btn-primary">LOGIN</div>
</div>
 			</div>
 		</div>
         </div>
 </section>