<section id="services" class="services" style="margin-top:66px;">
  <div class="container">
<div class="contentbg" style="padding-bottom:68px;">
    <div class="section-title">
      <h2>Produk </h2>
    </div>

    <div class="row">
   
   <div class="col-lg-4 col-md-4 d-flex align-items-stretch mt-4">
     
   </div>
 <div class="col-lg-4 col-md-4 d-flex align-items-stretch mt-5">
 <div class="icon-box" style="color:#000000;">Authorized Distributor
       <img src="<?php echo base_url(); ?>asset/foto_mitra/dahuanew1.png" alt="" class="img-fluid" style="width:92%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
       <p><a class='btn btn-outline-secondary' href='<?php echo base_url() .'kategori/detail/dahua'; ?>'>Selengkapnya</a></p>
     </div>
   </div>
    <div class="col-lg-4 col-md-4 d-flex align-items-stretch mt-4">
   
   </div>

  
   <div class="col-lg-1">
</div>
    <div class="col-lg-3 col-md-6 d-flex align-items-stretch mt-5" style="color:#000000;">
    <div class="icon-box solel">Sole Distributor
       <img src="<?php echo base_url(); ?>asset/foto_mitra/dspanew30.png" alt="" class="img-fluid" style="width:100%;">
      
       <p><a class='btn btn-outline-secondary'href='<?php echo base_url() .'kategori/detail/dsppa'; ?>'>Selengkapnya</a></p>
     </div>
   </div>
   <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-5">
   <div class="icon-box" style="color:#000000;padding:70px;padding-top:0px;">Authorized Partner
       <img src="<?php echo base_url(); ?>asset/foto_mitra/zkteconew1.png" alt="" class="img-fluid" style="width:90%;">
      
         <p><a class='btn btn-outline-secondary tgh' href='<?php echo base_url() .'kategori/detail/zkteco'; ?>'>Selengkapnya</a></p>
     </div>
   </div>
   <div class="col-lg-3 col-md-6 d-flex align-items-stretch mt-5">
   <div class="icon-box soler">Authorized Partner
       <img src="<?php echo base_url(); ?>asset/foto_mitra/seagatenew1.png" alt="" class="img-fluid" style="width:100%;">
       
         <p><a class='btn btn-outline-secondary' href='<?php echo base_url() .'kategori/detail/seagate'; ?>'>Selengkapnya</a></p>
     </div>
   </div>

   <div class="col-lg-1">
</div>
</div>
 </div>
  </div>
</section>