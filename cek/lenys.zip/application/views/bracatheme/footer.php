<div class="container" style="padding:0 !important;width:100% !important;">
<div class="col-lg-2"><a href="<?php echo base_url();?>"><img src='<?php echo base_url('assets/img/'); ?>lenyskincare_icon.png' style="border-radius:50px;box-shadow:none;" class='img-responsive logofooter' width="30%;" alt=''></a></div>
    <div class="col-lg-2" style="padding-top:15px"><a href="<?php echo base_url('treatment'); ?>">Treatment</a></div>
    <div class="col-lg-2" style="padding-top:15px"><a href="<?php echo base_url('lenyskincaretips'); ?>">Berita</a></div>
    <div class="col-lg-2" style="padding-top:15px"><a href="<?php echo base_url('karir'); ?>">Karir</a></div>
    <div class="col-lg-2" style="padding-top:15px"><a href="<?php echo base_url('hubungi');?>">Hubungi Kami</a></div>
    <div class="col-lg-2 trademark"><a href="<?php echo $pecahd[0]; ?>"><i class="bx bxl-instagram" style="font-size:1.9em"></i></a> <a href="<?php echo $pecahd[1]; ?>"><i class="bx bxl-facebook" style="font-size:1.9em"></i></a> <a href="<?php echo $pecahd[2]; ?>"><i class="bx bxl-tiktok" style="font-size:1.9em"></i></a><a href="<?php echo $pecahd[3]; ?>"> <i class="bx bxl-youtube" style="font-size:1.9em"></i></a><div style="font-size:0.8em;font-family:verdana;"><i>powered by elokreatif</i></div></div>
      </div>
  