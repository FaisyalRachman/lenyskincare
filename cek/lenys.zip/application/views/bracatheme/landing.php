<h3>Statistik Pengunjung</h3>
 
<table id="foot-table-list">
<tr> 
 
   <td>Pengunjung Hari ini</td>
 
   <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
 
   <td><?php echo $pengunjunghariini ?> orang</td>
 
</tr>
 
<tr>
 
   <td>Total Pengunjung</td> 
 
   <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
 
   <td><?php echo $totalpengunjung ?> orang</td>
 
</tr>
 
<tr>
 
   <td>Pengunjung Online</td>
 
   <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
 
   <td><?php echo $pengunjungonline ?> orang</td>
 
</tr>
 
</table>