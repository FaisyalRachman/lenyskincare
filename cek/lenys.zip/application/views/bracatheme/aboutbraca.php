<section id="contact" class="contact" style="margin-top:65px;">
      <div class="container">
 
        <div class="row mt-0">
        <div class="col-lg-1" style="padding:0px !important;">
     
     </div>
          <div class="col-lg-3">
          
          <h4><b>ABOUT US</b></h4>
        <img  src="<?php echo base_url(); ?>assets/img/aboutbraca.png" class="img-fluid" style="width:90%;">
          </div>

          <div class="col-lg-7" style="text-align:left; margin-top:20px;"><br>
          <p style="font-family:Roboto;font-size:1.2vw;"><?php echo $record['isi_halaman']; ?></p>
          </div>
          <div class="col-lg-1" style="padding:0px !important;">
     
     </div>
          </div>
<br><br>
          <div class="row"> 
               <div class="col-lg-2" style="padding:0px !important;">
     
     </div>
        <div class="col-lg-9" style="padding:0px !important;">
        <img  src="<?php echo base_url(); ?>assets/img/run_stickbraca.png" class="img-fluid" style="width:90%;">
          
          </div>
          <div class="col-lg-1" style="padding:0px !important;">
     
     </div>
          <br><br><br>
       

        </div>
      
       <div class="row"> 
          <div class="col-lg-12 text-center">
    
        <img src="<?php echo base_url(); ?>assets/img/excelent_braca.png" class="img-fluid" style="margin-top:95px;width:75%;">
                  
     </div>
                </div>
                <br><br>
                <div class="row"> 
                <div class="col-lg-1 text-center">
</div>
          <div class="col-lg-4 text-center">
    
        <img src="<?php echo base_url(); ?>assets/img/excelent_braca_founder.png" class="img-fluid" style="width:60%;">
                  
     </div>
     <div class="col-lg-4 text-center" style="margin-top:25px">
    
    <p style="font-family:Roboto;font-size:1.2vw;text-align:left"><?php echo $record['isi_halaman1']; ?></p>
              
 </div>
                </div>
    </section>