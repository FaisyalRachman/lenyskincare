<section id="services" class="services" style="margin-top:66px;">
  <div class="container">
<div style="background-color:#0C152A;border-top:1px solid #1C172A;">
    <div class="section-title" style="color:#ffffff !important;">
      <h2 style="color:#ffffff">Service </h2>
    </div>
    <div class="row">
    <div class="col-lg-1">
    </div>
    <div class="col-lg-2">
     <div class="icon-box">
       <img src="<?php echo base_url(); ?>asset/images/s1.png" alt="" class="img-fluid" style="width:63%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
       <p style="color:#ffffff;font-size:13px;"><b>Service Setting</b></p><ul style="color:#ffffff;font-size:10px;"><li>o Setting & Konfigurasi fungsi analitik kamera</li><li>o Setting & Konfigurasi fungsi pemantauan</li></ul>
     </div>
   </div>
    <div class="col-lg-2">
     <div class="icon-box">
       <img src="<?php echo base_url(); ?>asset/images/s2.png" alt="" class="img-fluid" style="width:63%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
       <p style="color:#ffffff;font-size:13px;"><b>Service Training</b></p><ul style="color:#ffffff;font-size:10px;"><li>o Memberikan pelatihan untuk Instalasi</li><li>o Memberikan pelatihan untuk pengoperasian pada sistem</li></ul>
     </div>
   </div>
    <div class="col-lg-2">
     <div class="icon-box">
       <img src="<?php echo base_url(); ?>asset/images/s3.png" alt="" class="img-fluid" style="width:63%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
               <p style="color:#ffffff;font-size:13px;"><b>Service Maintenance</b></p><ul style="color:#ffffff;font-size:10px;"><li>o Melakukan pemeriksaan sistem secara berkala</li><li>o Memberikan tanggapan atas permasalahan sistematik</li>
               <li>o Memberikan tanggapan atas permasalahan pada peralatan</li><li>o Memberikan laporan dari hasil pemeriksaan</li></ul>
     </div>
   </div>
   <div class="col-lg-2">
     <div class="icon-box">
       <img src="<?php echo base_url(); ?>asset/images/s4.png" alt="" class="img-fluid" style="width:63%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
       <p style="color:#ffffff;font-size:12px;"><b>Service Supervision</b></p><ul style="color:#ffffff;font-size:10px;"><li>o Memastikan instalasi sesuai dengan prosedur yang benar</li><li>o Melakukan pemantauan saat proses instalasi dilakukan</li></ul>
     </div>
   </div>
   <div class="col-lg-2">
     <div class="icon-box">
       <img src="<?php echo base_url(); ?>asset/images/s5.png" alt="" class="img-fluid" style="width:63%;">
       <h5 style="text-align:left;"><a href="<?php echo base_url() . $row['judul_seo']; ?>" style="color:#004488;font-weight:bold"></a></h5>
       <p style="color:#ffffff;font-size:12px;"><b>Service Commisioning</b></p><ul style="color:#ffffff;font-size:10px;"><li>o Melakukan testing pada sistem</li><li>o Memberikan Trial & Error pada product</li>
               <li>o Dokumentasi fisik & sistem</li></ul>
     </div>
   </div>
   <div class="col-lg-1">
    </div>
</div>
<br><br>
</div>
</div>
</section>