<section id="contact" class="contact" style="margin-top:18px;">
      <div class="container">
      <div class="contentbg">
   
      <div class="container">
 
        <div class="row mt-5">
      
          <div class="col-lg-6" style="margin-left:45px !important;">
          <br><br>
          <h4><b>Tentang Kami</b></h4>
        <p style="font-size:1.3rem;">  Integra Mitra Solusi adalah Perusahaan Distribusi Sistem Keamanan di Indonesia yang berpusat di Jakarta dan dilengkapi dengan tim yang profesional dan berpengalaman, saat ini integra bersama dengan para Mitra sudah banyak mengerjakan proyek dari skala kecil sampai skala besar.</p>
          </div>

          <div class="col-lg-5" style="text-align:center; margin-top:20px;"><br>
          <img  src="<?php echo base_url(); ?>asset/images/group_gedung.png" class="img-fluid" style="width:90%;">
           
          </div>
          <div class="col-lg-1" style="padding:0px !important;">
     
     </div>
          </div>

          <div class="row mt-5">
        <div class="col-lg-1" style="padding:0px !important;">
    
          </div>
          <div class="col-lg-5" style="padding:0px !important;">
          <img  src="<?php echo base_url(); ?>asset/images/group_target.png" class="img-fluid">
          </div>

          <div class="col-lg-6" style="text-align:left;">
          <h4><b>Visi</b></h4>
          <p style="font-size:1.3rem;"> Menjadi distributor pelopor industri solusi keamanan di Indonesia</p>
<br>
<br>
<h4><b>Misi</b></h4>
<ul style="font-size:1.3rem;"> 
<li> Memiliki produk terlengkap dan berkualitas</li>
<li> Memiliki tim berkomitmen mengedepankan   
    profesionalitas</li>
    <li>  Membangun perusahaan yang berintegritas tinggi</li>
    <li>  Memenuhi kepuasan pelanggan dalam bentuk       
    pelayanan sempurna</li>
</ul>
           
          </div>
          
          </div>
          <br><br><br>
          <div class="row">
        
          <div class="card col-lg-10" style="background:#0C152A;">
          <div class="col-sm-12 solevideo">
          <div class="video-container">
          <iframe style="border:15px solid #Fcc930;" width="720" height="315"
src="<?= $record['video'] ?>">
</iframe>
</div>
          </div>
          </div>
          <div class="col-lg-1">

      
          </div>
          
          </div>

        </div>
       <br><br><br>
        </div>
      </div>
    </section>