 <div class="container">
      <div class="contentbgfooter">
   <div class="row">

     <div class="col-md-auto footer-contact">
       <p>
           Copyright &copy; 2021 <strong><span>PT.Integra Mitra Solusi</span></strong><br>
         <?php echo $sosmed['rekening']; ?>
        
              </p>
              <br>
       <p>
          <div class="social-links text-center text-md-left pt-3 pt-md-0">
        <a href="<?php echo $pecahd[1]; ?>" class="twitter"><i class="bx bxl-linkedin"></i></a>
        <a href="<?php echo $pecahd[0]; ?>" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="<?php echo $pecahd[2]; ?>" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="<?php echo $pecahd[3]; ?>" class="youtube"><i class="bx bxl-youtube"></i></a>
      </div>
      <div class="text-center text-md-left pt-3 pt-md-3">
        <small><strong><a href="https://elokreatif.com" target="_blank" style="font-size:11px;color:#2C3E50;">Powered by Elokreatif</a></strong></small>
</div>
    </p>
     </div>

     <div class="col-md-1 col-md-2 footer-links bwh">
   
       <h4>Profil</h4>
       <ul>
         <li> <a href="<?= base_url() ?>aboutims/detail">Tentang Kami</a></li> 
         <li> <a href="<?= base_url() ?>profesionalteam">Profesional Team</a></li>
         <li> <a href="<?= base_url() ?>services">Service</a></li>
         </ul>
    
      </div>

     <div class="col-md-1 col-md-1 footer-links bwh">
       <h4>Produk</h4>
       <ul>
         <li> <a href="<?= base_url() ?>kategori/detail/dahua">Dahua</a></li>
         <li> <a href="<?= base_url() ?>kategori/detail/dsppa">DSPPA</a></li>
         <li> <a href="<?= base_url() ?>kategori/detail/zkteco">ZKteco</a></li>
         <li> <a href="<?= base_url() ?>kategori/detail/seagate">Seagate</a></li>
        
       </ul>
     </div>
      <div class="col-md-1 footer-links bwh">
       <h4>Projects</h4>
       <ul>
         <li> <a href="<?= base_url() ?>projectclient">Clients</a></li>
         <li> <a href="<?= base_url() ?>testimoni">Testimoni</a></li>
        
       </ul>
     </div>
<div class="col-md-1 footer-links bwh">
       <h4>Berita</h4>
       <ul>
         <li> <a href="<?= base_url() ?>artikel">Article</a></li>
         <li> <a href="<?= base_url() ?>albums">Publikasi</a></li>
        
       </ul>
     </div>
<div class="col-md-1 footer-links bwh">
       <h4>Karir</h4>
       <ul>
         <li> <a href="<?= base_url() ?>culture">Culture</a></li>
         <li> <a href="<?= base_url() ?>lowongan">Lowongan</a></li>
        
       </ul>
     </div>
    <div class="col-md-2 footer-links bwh">
       <h4>Kontak</h4>
       <ul>
         <li> <a href="<?php echo base_url(); ?>hubungi">Meet Us</a></li>
        
       </ul>
     </div>

   </div>
 </div>
  </div>